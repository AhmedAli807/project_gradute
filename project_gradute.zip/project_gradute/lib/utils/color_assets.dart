import 'package:flutter/material.dart';

class ColorAssets{
  static Color kColor=const Color(0xff375A64);
  static Color secondaryColor=const Color(0xffFF735D);
  static Color backgroundColor= Colors.white;
}