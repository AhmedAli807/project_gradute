import 'package:flutter/material.dart';
import 'package:project_gradute/views/All_Screens/all_screens_view_body.dart';

class AllScreensView extends StatelessWidget {
  const AllScreensView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const AllScreensViewBody();
  }
}
