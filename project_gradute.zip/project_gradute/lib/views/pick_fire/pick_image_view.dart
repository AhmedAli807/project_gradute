import 'package:flutter/material.dart';
import 'package:project_gradute/views/pick_fire/widgets/pick_image_view_body.dart';

class PickImageView extends StatelessWidget {
  const PickImageView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PickImageViewBody();
  }
}
