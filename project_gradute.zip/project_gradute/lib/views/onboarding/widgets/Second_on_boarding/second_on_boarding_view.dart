import 'package:flutter/material.dart';
import 'package:project_gradute/views/onboarding/widgets/Second_on_boarding/widgets/second_on_boarding_view_body.dart';

class SecondOnBoardingView extends StatelessWidget {
  const SecondOnBoardingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SecondOnBoardingViewBody();
  }
}
