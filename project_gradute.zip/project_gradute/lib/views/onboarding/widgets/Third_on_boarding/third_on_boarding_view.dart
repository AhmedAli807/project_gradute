import 'package:flutter/material.dart';
import 'package:project_gradute/views/onboarding/widgets/Third_on_boarding/widgets/third_on_boarding_view_body.dart';

class ThirdOnBoardingView extends StatelessWidget {
  const ThirdOnBoardingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const ThirdOnBoardingViewBody();
  }
}
