import 'package:flutter/material.dart';
import 'package:project_gradute/views/onboarding/widgets/First_on_boarding/widgets/first_on_boarding_view_body.dart';

class FirstOnBoardingView extends StatelessWidget {
  const FirstOnBoardingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const FirstOnBoardingViewBody();
  }
}
