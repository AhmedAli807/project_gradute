import 'package:flutter/material.dart';
import 'package:project_gradute/views/onboarding/widgets/Fourth_on_boarding/widgets/fourth_on_boarding_view_body.dart';

class FourthOnBoardingView extends StatelessWidget {
  const FourthOnBoardingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const FourthOnBoardingViewBody();
  }
}
