import 'package:firebase_core/firebase_core.dart';

class FirebaseOptionMethod {
 static FirebaseOptions firebaseOptions() {
    return const FirebaseOptions(
        apiKey: 'AIzaSyBmmzwrU7pP4DpwSzHPrKpxbXKUS4FIhOE',
        appId: '1:114245126028:android:dacae104ae5beca3b538a9',
        messagingSenderId: '114245126028',
        projectId: 'nasaproject-e7531');
  }

}