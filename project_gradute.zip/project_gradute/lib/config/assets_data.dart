class AssetsData{
  static String logo='assets/images/antifire.png';
  static String google='assets/images/Google.png';
  static String fireMarker='assets/images/fire_marker.png';
}