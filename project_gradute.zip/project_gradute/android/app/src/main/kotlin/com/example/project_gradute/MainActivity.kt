package com.example.project_gradute

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
